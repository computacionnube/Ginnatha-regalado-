﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Compañia_alquiler_autos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double adk;
        double efec, valor=0, tot=0;

        private void txtkilo_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsDigit(letra) && letra != 13 && letra != 8 && letra != 46)
                e.Handled = true;
            if (letra == 13)
            {
                btncalcular.Enabled = true;
                btncalcular.Focus();
            }
        }

        private void txtefectivo_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsDigit(letra) && letra != 13 && letra != 8 && letra != 46)
                e.Handled = true;
            if (letra == 13)
            {
                btnpagar.Enabled = true;
                btnpagar.Focus();
            }
        }

        private void btnsalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            efec = Convert.ToInt32(txtefectivo.Text);
            if (int.Parse(txtopc.Text)==1)
            {
                lstpresentacion.Items.Add("SISTEMA DE FACTURACION  Venta de AUTOS");
                lstpresentacion.Items.Add("");
                lstpresentacion.Items.Add("Usted ah seleccionado opcion:" + txtopc.Text);
                adk = ((17550 * 12) / 100);
                lstpresentacion.Items.Add("Mas iVA 12%");
                txtiva.Text = (adk).ToString();
                double total = 17550 + adk;
                txttotal.Text = (total).ToString();
                tot = efec - total;
                txtcambio.Text = tot.ToString();
                lstpresentacion.Items.Add("Correspondiente a un valor de: " + txttotal.Text);
            }
            else
            {
                if (int.Parse(txtopc.Text)==2)
                {
                lstpresentacion.Items.Add("SISTEMA DE FACTURACION Venta de AUTOS");
                lstpresentacion.Items.Add("");
                lstpresentacion.Items.Add("Usted ah seleccionado opcion:" + txtopc.Text);            
                adk = ((22000 * 12) / 100);
                lstpresentacion.Items.Add("Mas iVA 12%");
                txtiva.Text = (adk).ToString();
                double total2 = 22000 + adk;
                txttotal.Text = (total2).ToString();
                double tot2 = efec-total2;
                    txtcambio.Text = tot2.ToString();
                    lstpresentacion.Items.Add("Correspondiente a un valor de: " + txttotal.Text);
                }
                else
                {
                    if (int.Parse(txtopc.Text) == 3)
                    {
                   
                        lstpresentacion.Items.Add("SISTEMA DE FACTURACION Venta de AUTOS");
                        lstpresentacion.Items.Add("");
                        lstpresentacion.Items.Add("Usted ah seleccionado opcion:" + txtopc.Text);
                        adk = ((24420 * 12) / 100);
                        lstpresentacion.Items.Add("Mas iVA 12%");
                        txtiva.Text = (adk).ToString();
                        double total3 = 24420 + adk;
                        txttotal.Text = (total3).ToString();
                        double tot3 = efec - total3;
                        txtcambio.Text = tot3.ToString();
                        lstpresentacion.Items.Add("Correspondiente con un valor de: " + txttotal.Text);
               
                    }
                    else
                    {
                        if (int.Parse(txtopc.Text) == 4)
                        {
                            lstpresentacion.Items.Add("SISTEMA DE FACTURACION Venta de AUTOS");
                            lstpresentacion.Items.Add("");
                            lstpresentacion.Items.Add("Usted ah seleccionado opcion:" + txtopc.Text);
                            adk = ((12350 * 12) / 100);
                            lstpresentacion.Items.Add("Mas iVA 12%");
                            txtiva.Text = (adk).ToString();
                            double total4 = 12420 +adk;
                            txttotal.Text = (total4).ToString();
                            double tot4 = efec - total4;
                            txtcambio.Text = tot4.ToString();
                            lstpresentacion.Items.Add("Correspondiente con un valor de: " + txttotal.Text);
                        }

                    }
                }
            }
            txtefectivo.Focus();
        }

        private void btnpagar_Click(object sender, EventArgs e)
        {
            
            if (double.Parse(txtefectivo.Text) < double.Parse(txttotal.Text))
            {
                MessageBox.Show("Error, vuelva a ingresar la cantidad", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtefectivo.Text = null;
                txtefectivo.Focus();
            }
            else
            {
                txtcambio.Text = (double.Parse(txtefectivo.Text) - double.Parse(txttotal.Text)).ToString();
            }
            
        }

        private void btnnuevo_Click(object sender, EventArgs e)
        {
            txtcambio.Text = null;
            txtefectivo.Text = null;
            txttotal.Text = null;
            txtopc.Text = null;
            txtiva.Text = null;
            lstpresentacion.Items.Clear();
            btncalcular.Enabled = false;
            btnpagar.Enabled = false;
            txtopc.Focus();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtcambio_TextChanged(object sender, EventArgs e)
        {

        }


    }
}
